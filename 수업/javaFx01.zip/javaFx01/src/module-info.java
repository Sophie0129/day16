module javaFx01 {
	exports borderpane;
	exports javaFx01;
	exports gridPane;

	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
}